﻿var Controller = new function () {
    var callarOptions, service = {}, filter = { "field": "InvestigationId", "value": "", Operation: 0 };
    function getView() {
        return $(`<div><div id="summary_container" class="row">
                                        </div>
                                        <div id="filter_container" class="row">
                                        </div>
                                        <div style="margin-top:10px;">
                                            <div id="button_container" class="empty_style button_container row">
                                                <a href="#" class="btn btn-white btn-success btn-round pull-right" id="btn_add_new_report_category" style="margin-left: 1%"><span class="glyphicon glyphicon-plus"></span>New</a>
                                            </div>
                                            <div id="grid_container">
                                            </div>
                                        </div></div>`);
    };

    this.Show = function (model) {
        callarOptions = model;
        filter.value = model.InvestigationId;
        Global.Add({
            title: 'Investigation',
            OnChange: model.OnChange,
            Tabs: [
                {
                    title: 'Basic Info',
                    Columns: [
                        { field: 'Name', title: 'Test Name', filter: true, position: 4, Add: { sibling: 3 } },
                        { field: 'InvestigationCategory', title: 'Category', filter: true, Add: false, position: 1 },
                        { field: 'Room', title: 'Room', filter: true, Add: false, position: 3 },
                        { field: 'Cost', title: 'Cost', position: 9, Type: 2, Add: { sibling: 3, dataType: 'float' } },
                        { field: 'MaxDiscount', title: 'Max Discount', position: 9, Type: 2, required: false, selected: false, Add: { sibling: 3, dataType: 'float|null' } },
                        { field: 'CreatedAt', title: 'CreatedAt', dateFormat: 'dd mmm-yyyy', Add: false, selected: false },
                        { field: 'UpdatedAt', title: 'UpdatedAt', dateFormat: 'dd mmm-yyyy', Add: false, selected: false },
                        { field: 'Creator', add: false, filter: true },
                        { field: 'Remarks', title: 'Remarks', filter: true, required: false, Add: { type: 'textarea', sibling: 1 } }
                    ],
                    DetailsUrl: function () {
                        return '/InvestigationArea/Investigation/Details?Id=' + callarOptions.InvestigationId;
                    }
                },
                {
                    title: 'Items',
                    Grid: [service.ReportCategory.Bind],
                }
            ],
            name: 'OnInvestigationDetails',
            url: '/Content/IqraService/Js/OnDetailsWithTab.js?v=InvestigationDetails',
        });
    };
    (function () {
        var gridModel;
        function onSubmit(formModel, data) {
            if (data) {
                formModel.Id = data.Id
            }
            formModel.InvestigationId = callarOptions.InvestigationId
            formModel.Title = formModel.TitleText;
        };
        function onCreatorDetails(model) {
            Global.Add({
                UserId: model.CreatedBy,
                name: 'UserDetails',
                url: '/Content/IqraHMS/PatientArea/Js/User/UserDetails.js',
            });
        };
        function onDetails(model) {
            Global.Add({
                model: model,
                name: 'InvestigationDetails',
                url: '/Content/IqraHMS/InvestigationArea/Js/InvestigationReportCategory/OnDetails.js',
            });
        };
        function rowBound(elm) {
            if (this.IsDeleted) {
                elm.css({ color: 'red' }).find('.glyphicon-trash').css({ opacity: 0.3, cursor: 'default' });
                elm.find('a').css({ color: 'red' });
            }
        };

        function onDataBinding(response) {
            response.Data.Data.each(function () {
                this.TitleText = this.Title;
            });
        };
        function bind(container) {
            Global.List.Bind({
                Name: 'InvestigationReportCategory',
                Grid: {
                    elm: container.find('#grid_container'),
                    columns: [
                            { field: 'TitleText', Title: 'Title', filter: true, position: 1, click: onDetails, required: false, },
                            { field: 'Position', position: 2, Add: { datatype: 'int' } },
                            { field: 'CreatedAt', title: 'CreatedAt', dateFormat: 'dd mmm-yyyy', Add: false},
                            { field: 'UpdatedAt', title: 'UpdatedAt', dateFormat: 'dd mmm-yyyy', Add: false, selected: false },
                            { field: 'Creator', add: false, filter: true, click: onCreatorDetails },
                            { field: 'Remarks', title: 'Remarks', filter: true, required: false, Add: { type: 'textarea', sibling: 1 } }
                    ],
                    url: '/InvestigationArea/InvestigationReportCategory/Get',
                    page: { 'PageNumber': 1, 'PageSize': 10, showingInfo: ' {0}-{1} of {2} Items ', filter: [filter] },
                    rowBound: rowBound,
                    onDataBinding: onDataBinding,
                    Printable: {
                        Container: function () {
                            return container.find('#button_container');
                        },
                        html: '<a class="btn btn-default btn-round btn_add_print pull-right" style="margin: 0px;"><span class="glyphicon glyphicon-print"></span> Print </a>'
                    }
                },
                onComplete: function (model) {
                    gridModel = model;
                },
                Add: {
                    elm: container.find('#btn_add_new_report_category'),
                    onSubmit: onSubmit,
                    save: '/InvestigationArea/InvestigationReportCategory/Create',
                    saveChange: '/InvestigationArea/InvestigationReportCategory/Edit',
                    //additionalField: [{ field: 'TitleText',title:'Title',position: 1 }]
                },
                remove: { save: '/InvestigationArea/InvestigationReportCategory/Delete' }
            });
        };
        this.Bind = function (windowModel, container, position, model, func) {
            var tabModel = {}, view = getView();
            container.append(view);
            model.Reload = function () {
                bind(view);
                model.Reload = function () {
                    gridModel && gridModel.Reload();
                };
            };
        };
    }).call(service.ReportCategory = {});
};