
(function () {
    function onSubmit(formModel, data) {
        if (data) {
            formModel.Id = data.Id
        }
    };
    function onDeliver(model) {
        if (model && (model.Status == 'Done' || model.Status == 'Delivered')) {
            alert('This Report is already '+model.Status+'.');
            return;
        }
        Global.Controller.Call({
            url: IqraConfig.Url.Js.WarningController,
            functionName: 'Show',
            options: {
                name: 'Warning',
                Message: 'Is this Investigation Ready to Deliver ?',
                Save: '/InvestigationArea/PathologistInvestigationStatus/ChangeStatus',
                data: { Id: model.Id },
                onsavesuccess: function (response) {
                    gridModel.Reload();
                }
            }
        });
    };
    function onPatientDetails(model) {
        Global.Add({
            PatientId: model.PatientId,
            name: 'PatientDetails',
            url: '/Content/IqraHMS/PatientArea/Js/Patient/PatientDetails.js',
        });
    };
    function onPatientInvestigatioDetails(model) {
        Global.Add({
            name: 'PatientInvestigationDetails',
            url: '/Content/IqraHMS/InvestigationArea/Js/PatientInvestigation/OnDetails.js',
            PatientInvestigationId: model.PatientInvestigationId,
            model: {}
        });
    };
    function onDoctorDetails(model) {
        Global.Add({
            DoctorId: model.DoctorId,
            name: 'DoctorDetails',
            url: '/Content/IqraHMS/DoctorsArea/Js/Doctor/DoctorDetails.js',
        });
    };
    function rowBound(elm) {
        if (this.IsDeleted) {
            elm.css({ color: 'red' }).find('.glyphicon-trash').css({ opacity: 0.3, cursor: 'default' });
            elm.find('a').css({ color: 'red' });
        }
    };
    function onDataBinding(data) {
    };
    var that = this, gridModel;
    
    Global.List.Bind({
        Name: 'Investigation Status',
        Grid: {
            elm: $('#grid'),
            columns: [
                { field: 'Code', title: 'Code', filter: true },
                { field: 'Investigation', title: 'Investigation', filter: true, click: onPatientInvestigatioDetails },
                { field: 'Doctor', title: 'Doctor', filter: true, click: onDoctorDetails },
                { field: 'Patient', title: 'Patient', filter: true, click: onPatientDetails },
                { field: 'Status', title: 'Status', filter: false },
                { field: 'SampleCollectedAt', title: 'Sample Collected At', dateFormat: 'dd mmm-yyyy hh:mm', Add: false },
                { field: 'UpdatedAt', title: 'UpdatedAt', dateFormat: 'dd mmm-yyyy hh:mm', Add: false },
                { field: 'CreatedAt', title: 'CreatedAt', dateFormat: 'dd mmm-yyyy', Add: false },
                { field: 'Remarks', title: 'Remarks', required: false, sorting: false }
            ],
            Actions: [{
                click: onDeliver,
                html: '<a style="margin-right:8px;" id="btn_due_deliver" class="icon_container" title="Make Delivered"><span class="glyphicon glyphicon-check"></span></a>'
            }],
            url: '/InvestigationArea/PatientInvestigationList/StatusWiseInvList',
            page: { 'PageNumber': 1, 'PageSize': 10, showingInfo: ' {0}-{1} of {2} Samples ' }, 
            onDataBinding: onDataBinding,
            rowBound: rowBound
        }, onComplete: function (model) {
            gridModel = model;
        }, Add: false,
        Edit: false,
        remove: false
    });
})();;
