﻿
var Controller = new function () {
    var windowModel, formModel = {}, inputs = {}, callerOptions, service = {}, invgridModel,doctorModel;
    var maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    function printInvoice(id) {
        Global.Add({
            type: 'New',
            PatientInvestigationId: id,
            name: 'InvoicePrintPreview',
            url: '/Content/IqraHMS/BillingArea/Js/InvestigationInvoice/PrintInvestigationInvoice.js',
        });
    };
    function getPatient() {
        var model = {
            Gender: formModel.Gender,
            Mobile: formModel.Mobile,
            DateOfBirth: formModel.DateOfBirth + ' 00:00',
            Name: formModel.Name
        };
        return model;
    };
    function getModel() {
        var model = {},
        invlist = service.Investigation.GetInvData();
        model.InvItems = invlist;
        model.DoctorId = formModel.DoctorId;
        model.ReferenceId = formModel.ReferenceId;
        model.DiscountRemarks = formModel.DiscountRemarks;
        model.DiscountType = formModel.DiscountType || 1;
        model.Type = formModel.Type;
        model.DrCommission = formModel.DrCommission;
        model.ReCommission = formModel.ReCommission;
        model.TotalAmount = formModel.TotalAmount;
        model.DiscountTaka = formModel.DiscountT;
        model.DiscountPercentage = formModel.DiscountP;
        model.DiscountedAmount = formModel.DiscountedAmount;
        model.PaidAmount = formModel.PaidAmount;
        model.DueAmount = formModel.DueAmount;
        model.Patient = getPatient();
        //model.PatientId = callerOptions.model.Id;
        console.log(['getModel', model]);
        return model;
    };
    function save() {
        if (formModel.IsValid) {
            windowModel.Wait('Please Wait while saving data......');
            var model = getModel();
            console.log(['save', model]);
            Global.CallServer('/InvestigationArea/PatientInvestigation/CreateInvestigationWithNonePatient', function (response) {
                windowModel.Free();
                if (!response.IsError) {
                    callerOptions.onSaveSuccess(formModel, inputs);
                    close();
                    printInvoice(response.Id);
                } else {
                    Global.Error.Show(response, {});
                }
            }, function (response) {
                windowModel.Free();
                alert('Network Errors.');
            }, model, 'POST');
            console.log(['after save', model]);
        } else {
            alert('Validation Error.');
        }
    };
    function close() {
        windowModel && windowModel.Hide();
    };
    function onDatePickerChanged(date) {
        if (date) {
            var currentDate = new Date();
            var value = currentDate.getDate() - date.getDate(), flg = 0;
            if (value < 0) {
                formModel.Day = (value + maxDays[date.getMonth()]);
                flg = -1;
            } else {
                formModel.Day = value;
            }
            value = currentDate.getMonth() - date.getMonth() + flg; flg = 0;
            if (value < 0) {
                formModel.Month = (value + 12);
                flg = -1;
            } else {
                formModel.Month = value;
            }
            formModel.Year = currentDate.getFullYear() - date.getFullYear() + flg;
        } else {
            formModel.Year = 0;
            formModel.Month = 0;
            formModel.Day = 0;
        }
    };
    function onAgeChanged() {
        var date = new Date();
        date.setDate(date.getDate() - parseInt(formModel.Day || '0') || 0);
        date.setMonth(date.getMonth() - parseInt(formModel.Month || '0') || 0);
        date.setFullYear(date.getFullYear() - parseInt(formModel.Year || '0') || 0);
        formModel.DateOfBirth = date.format('dd/MM/yyyy');
    };
    function populate(isFirstTime) {
        if (callerOptions.model) {
            Global.Copy(formModel, callerOptions.model, true);
        } else {
            for (var key in formModel) formModel[key] = '';
        }
        service.DropDown.Reset(isFirstTime);
    };
    this.Show = function (model) {
        callerOptions = model;
        if (windowModel) {
            windowModel.Show();
            populate();
            service.Investigation.Empty();
        } else {
            Global.LoadTemplate('/Content/IqraHMS/InvestigationArea/Templates/CreateForNonePatient.html', function (response) {
                windowModel = Global.Window.Bind(response, { width: '95%' });
                inputs = Global.Form.Bind(formModel, windowModel.View);
                windowModel.View.find('.btn_cancel').click(close);
                Global.Click(windowModel.View.find('.btn_save'), save);
                service.Investigation.Bind();
                populate(true);
                windowModel.Show();
                service.Payment.Bind();
                service.DropDown.Bind();
                (['Day', 'Month', 'Year']).each(function () {
                    $(inputs[this + '']).keyup(onAgeChanged).blur(onAgeChanged);
                });
                Global.DatePicker.Bind($(inputs['DateOfBirth']), { format: 'dd/MM/yyyy', onchange: onDatePickerChanged });
            }, noop);
        }
    };
    (function () {//selectedValue: 'TransDate',
        var gendar = {
            dataSource: [
                { text: 'Male', value: 'Male' },
                { text: 'Female', value: 'Female' },
                { text: 'Other', value: 'Other' }
            ],
            selectedValue: 'Male'
        }, doctor = {
            url: '/DoctorsArea/Doctor/AutoCompleteWithMaxComminsion',
            change: function (data) {
                doctorModel = data;
            }
        }, discountType = {
            dataSource: [
                { text: 'Doctor', value: '1' },
                { text: 'Referral', value: '2' },
                { text: 'Hospital', value: '3' },
                { text: 'All', value: '4' }
            ],
            selectedValue: '1'
        }, reference = {
            url: '/ReferralArea/Reference/AutoComplete',
        };
        this.Bind = function () {
            doctor.elm = $(inputs['DoctorId']);
            discountType.elm = $(inputs['DiscountType']);
            reference.elm = $(inputs['ReferenceId']);
            gendar.elm = $(inputs['Gender']);


            Global.AutoComplete.Bind(doctor);
            Global.DropDown.Bind(discountType);
            Global.AutoComplete.Bind(reference);
            Global.DropDown.Bind(gendar);
        };
        this.Reset = function (isFirstTime) {
            formModel.DoctorId = '00000000-0000-0000-0000-000000000000';
            formModel.ReferenceId = '00000000-0000-0000-0000-000000000000';
            if (isFirstTime)
                return;

            doctor.val('');
            discountType.val('1');
            reference.val('');
            gendar.val('Male');
        };
    }).call(service.DropDown = {});
    (function () {
        var invsearchGridModel, filters = [],
            nameFilterModel = { "field": "Name", "value": "", Operation: 6 };
        function up(elm, func, option) {
            elm.keyup(function () {
                func.call(this, option);
            }).focus(function () { $(this).select(); });
            return elm;
        }

        function OnQuantityChanged(option) {
            var model = option.that,
                elm = option.elm,
                rate = model.Cost;
            model.Quantity = parseFloat(model.FormModel.Quantity || '0');
            var maxDiscount = model.MaxDiscount.mlt(model.Quantity);
            if (model.Discount > maxDiscount) {
                model.FormModel.Discount = model.Discount = maxDiscount;
            }
            model.NetAmount = model.Quantity.mlt(rate) - model.Discount;
            elm.find('.net_amount').html(model.NetAmount.toMoney(4));
            calculateAmount();
        };
        function onDiscountChanged(option) {
            var model = option.that,
                    elm = option.elm,
                maxDiscount = model.MaxDiscount.mlt(model.Quantity);
            model.Discount = parseFloat(model.FormModel.Discount || '0');
            if (model.Discount > maxDiscount) {
                model.FormModel.Discount = model.Discount = maxDiscount;
                alert('Exceed Max Discound');
            }
            model.NetAmount = model.Quantity.mlt(model.Cost) - model.Discount;
            elm.find('.net_amount').html(model.NetAmount.toMoney(4));
            calculateAmount();
        };
        function setIndex() {
            invgridModel.Body.view.find('tr').each(function (i) {
                var model = $(this).data('model');
                model.Position = i + 1;
            });
        };
        function onDelete(model) {
            var list = [];
            //gridModel.datasource.each(function () {
            //    if (this.Id != model.Id) {
            //        list.push(this);
            //    }
            //});
            invgridModel.datasource = invgridModel.dataSource = invgridModel.dataSource.where('itm=>itm.Id != "' + model.Id + '"');
            invgridModel.Reload();
            calculateAmount();
            setIndex();
        };
        function rowBound(elm) {
            elm.find('.qnt').html(up($('<input required="" data-type="float" data-binding="Quantity" class="form-control" type="text" style="width: calc(100% - 12px);" autocomplete="off">'), OnQuantityChanged, { that: this, elm: elm }));
            elm.find('.discount').html(up($('<input data-type="float|null" data-binding="Discount" class="form-control" type="text" style="width: calc(100% - 12px);" autocomplete="off">'), onDiscountChanged, { that: this, elm: elm }));
            this.FormModel = {};
            Global.Form.Bind(this.FormModel, elm);
            this.elm = elm;
            for (var key in this.FormModel) { if (typeof (this[key]) != 'undefined') this.FormModel[key] = this[key]; }
        };
        function onSubmit(formModel, data) {
            var value = formModel.Cost;
            formModel.Cost = '';
            for (var i = 0; i < value.length; i++) {
                formModel.Cost += value[i];
            }
            console.log("formModel.Cost");
        };
        function calculateAmount() {
            var amount = 0,discount=0;
            invgridModel.dataSource.each(function () {
                amount += this.NetAmount;
                discount += this.Discount;
            });

            formModel.DiscountedAmount = formModel.PaidAmount = amount;
            formModel.DueAmount = 0;
            formModel.DiscountT = discount;
            amount = amount + discount;
            formModel.TotalAmount = amount;

            if (amount != 0) {
                formModel.DiscountP = Math.ceil(discount * 100 / amount);
            } else {
                formModel.DiscountP = 0;
            }
        };
        function setInvGridModel() {
            Global.List.Bind({
                Name: 'Investigation',
                Grid: {
                    elm: windowModel.View.find('#investigation_grid_container'),
                    columns: [
                        { field: 'Position', title: 'Sr',width:30 },
                        { field: 'Code', title: 'Code', width: 50 },
                        { field: 'Name', title: 'Investigation Name', width: 200 },
                        { field: 'Quantity', title: 'Qnt', className: 'qnt', autobind: false },
                        { field: 'Cost', title: 'Rate', type: 2, autobind: false, className: 'cost' },
                        { field: 'Discount', title: 'Discount', autobind: false, className: 'discount' },
                        { field: 'NetAmount', title: 'Net Amount', className: 'net_amount', type: 2, autobind: false }
                    ],
                    Actions: [{
                        click: onDelete,
                        html: '<a style="margin-right:8px;" class="icon_container" title="Delete"><span class="glyphicon glyphicon-trash"></span></a>'
                    }],
                    action:{ width: 60 },
                    dataSource: [],
                    rowBound: rowBound,
                    Printable: false,
                    Responsive: false,
                    selector: false,
                    page: { 'PageNumber': 1, 'PageSize': 1000, showingInfo: ' {0}-{1} of {2} Investigations ' },
                },
                onComplete: function (model) {
                    console.log(model);
                    invgridModel = model;
                },
                Add: false,
                Edit: false,
                remove: false
            });
        };
        function getInvModel(model,position) {
            var inv = {
                Position:position,
                Discount: 0,
                Quantity: 1,
                NetAmount:model.Cost,
                Name: model.Name,
                Cost: model.Cost,
                Id: model.Id,
                Type: model.Type,
                Code: model.Code,
                MaxDiscount: model.MaxDiscount,
                MaxDiscountP: model.MaxDiscount.div(model.Cost).mlt(100),
                CategoryName: model.InvestigationCategory,
                InvestigationCategoryId: model.InvestigationCategoryId
            };
            inv.DrCommission = model.DrCommission < 0 ? model.CtgrDrCommission : model.DrCommission;
            inv.ReCommission = model.ReCommission < 0 ? model.CtgrReCommission : model.ReCommission;
            return inv;
        };
        function setInvSearchGridModel() {
            filters = [nameFilterModel];
            Global.Grid.Bind({
                elm: windowModel.View.find('#inv_search_grid_container'),
                columns: [
                    { field: 'Name', title: 'Investigation Name', filter: true },
                    { field: 'Cost', title: 'Cost', filter: true },
                    { field: 'MaxDiscount', title: 'Max Discount', filter: true },
                ],
                Printable: false,
                Responsive: false,
                selector: false,
                //dataSource: [],
                url: '/InvestigationArea/Investigation/Get',
                page: { 'PageNumber': 1, 'PageSize': 10, showingInfo: ' {0}-{1} of {2} Investigations ', filter: filters },
                rowBound: function (elm) {
                    Global.Click(elm, function (model) {
                        if (invgridModel.dataSource.where('itm=>itm.Id=="' + model.Id + '"').length < 1) {
                            invgridModel.dataSource.push(getInvModel(model, invgridModel.dataSource.length + 1));
                            invgridModel.Reload();
                            calculateAmount();
                            windowModel.View.find('#inv_search_grid_container').hide();
                            $(inputs['InvestigationId']).blur();
                        } else {
                            alert('This Item is already Added.');
                        }
                    }, this);
                },
                onSubmit: onSubmit,
                onComplete: function (model) {
                    model.dataSource = none;
                    invsearchGridModel = model;
                    windowModel.View.find('#inv_search_grid_container').hide();
                }
            });
        };
        function setCommission(model, position) {
            var inv = {
                Code: model.Code,
                InvestigationId: model.Id,
                Cost: model.Cost,
                CommissionType: model.Type,
                Position: model.Position,
                Quantity: model.Quantity,
                NetAmount: model.NetAmount,
                Discount: model.Discount
            };
            var dt = parseFloat(formModel.DiscountT || '0') || 0;
            var dp = parseFloat(formModel.DiscountP || '0') || 0;
            if (dt > 0) {
                if (formModel.DiscountType === '4') {
                    var cost = model.Cost - dt;
                    if (model.Type == 'Percentage') {
                        inv.DrCommission = cost.mlt(model.DrCommission).div(100);
                        inv.ReCommission = cost.mlt(model.ReCommission).div(100);
                    } else {
                        inv.DrCommission = model.DrCommission - model.DrCommission.mlt(dp).div(100);
                        inv.ReCommission = model.ReCommission - model.ReCommission.mlt(dp).div(100);
                    }
                } else if (formModel.DiscountType === '3') {
                    if (model.Type == 'Percentage') {
                        inv.DrCommission = model.Cost.mlt(model.DrCommission).div(100);
                        inv.ReCommission = model.Cost.mlt(model.ReCommission).div(100);
                    } else {
                        inv.DrCommission = model.DrCommission;
                        inv.ReCommission = model.ReCommission;
                    }
                } else if (formModel.DiscountType === '2') {
                    if (model.Type == 'Percentage') {
                        inv.DrCommission = model.Cost.mlt(model.DrCommission).div(100);
                        inv.ReCommission = model.Cost.mlt(model.ReCommission - dp).div(100);
                    } else {
                        inv.DrCommission = model.DrCommission;
                        inv.ReCommission = model.ReCommission - model.Cost.mlt(dp).div(100);
                    }
                } else if (formModel.DiscountType === '1') {
                    if (model.Type == 'Percentage') {
                        inv.DrCommission = model.Cost.mlt(model.DrCommission - dp).div(100);
                        inv.ReCommission = model.Cost.mlt(model.ReCommission).div(100);
                    } else {
                        inv.DrCommission = model.DrCommission - model.Cost.mlt(dp).div(100);
                        inv.ReCommission = model.ReCommission;
                    }
                }
            } else {
                if (model.Type == 'Percentage') {
                    inv.DrCommission = model.Cost.mlt(model.DrCommission).div(100);
                    inv.ReCommission = model.Cost.mlt(model.ReCommission).div(100);
                } else {
                    inv.DrCommission = model.DrCommission;
                    inv.ReCommission = model.ReCommission;
                }
            }
            if (doctorModel) {
                inv.DrCommission = inv.DrCommission.mlt(doctorModel.MaxCommission).div(100);
            }

            return inv;
            //public DateTime DeliveryDate { get; set; }= DateTime.MaxValue

        };
        this.Bind = function () {
            setInvGridModel();
            setInvSearchGridModel();
            $(inputs['InvestigationId']).focus(function () {
                var offset = $(this).offset();
                offset.top += 15;
                offset.left = 0;
                windowModel.View.find('#inv_search_grid_container').css(offset).show();
            }).keyup(function () {
                if (formModel.InvestigationId != nameFilterModel.value) {
                    nameFilterModel.value = formModel.InvestigationId;
                    //invsearchGridModel.dataSource = invsearchGridModel.datasource = none;
                    invsearchGridModel.Reload();
                }
            }).blur(function () {
                //windowModel.View.find('#inv_search_grid_container').hide();
            }).closest('.input-group').mousedown(function (e) {
                e.stopPropagation();
            });
            windowModel.View.find('#inv_search_grid_container').mousedown(function (e) {
                e.stopPropagation();
            });
            $(document).mousedown(function () {
                windowModel.View.find('#inv_search_grid_container').hide();
            });
        };
        this.Get = function () {
            return invgridModel.dataSource;
        };
        this.GetInvData = function () {
            var invlist = [];
            invgridModel.dataSource.each(function (i) {
                invlist.push(setCommission(this, i))
            });
            return invlist;
        };
        this.Empty = function () {
            invgridModel.dataSource = invgridModel.datasource = [];
            invgridModel.Reload();
        };
    }).call(service.Investigation = {});
    (function () {
        var onChange = this.OnChange = {
            DiscountP: function () {
                var total = parseFloat(formModel.TotalAmount || '0') || 0,
                    discountP = parseFloat(formModel.DiscountP || '0') || 0;
                formModel.DiscountT = Math.ceil(total.mlt(discountP).div(100));
                service.Payment.OnChange.DiscountT();
            },
            DiscountT: function () {
                var total = parseFloat(formModel.TotalAmount || '0') || 0,
                    discountT = Math.ceil(parseFloat(formModel.DiscountT || '0') || 0),
                    dsct = discountT,
                    ttl = total,
                    dueAmount = parseFloat(formModel.DueAmount || '0') || 0,
                    paidAmount = parseFloat(formModel.PaidAmount || '0') || 0,
                    discount = total > 0 ? discountT.mlt(100).div(total) : 0, tk, amtp, discountedAmount;

                invgridModel.dataSource.orderBy('MaxDiscountP').each(function () {
                    amtp = this.Cost.mlt(this.Quantity);
                    if (discount > this.MaxDiscountP) {
                        tk = Math.ceil(amtp.mlt(this.MaxDiscountP).div(100));
                        discountT -= tk;
                        total -= amtp;
                        discount = discountT.mlt(100).div(total);
                    } else {
                        tk = Math.ceil(amtp.mlt(discount).div(100));
                        discountT -= tk;
                        total -= amtp;
                    }
                    this.NetAmount = amtp - tk;
                    this.FormModel.Discount = this.Discount = tk;
                    this.elm.find('.net_amount').html(this.NetAmount.toMoney(4));
                });
                if (discountT > 0.999) {
                    formModel.DiscountT = discountT = Math.ceil(dsct - discountT);
                    alert('Exceed Max Discound');
                    discount =discountT.mlt(100).div(ttl)
                }
                formModel.DiscountP =  Math.ceil(discount);
                formModel.DiscountedAmount = discountedAmount = ttl - discountT;
                var paidAmount = Math.min(paidAmount, discountedAmount);
                formModel.DueAmount = discountedAmount - paidAmount;
                formModel.PaidAmount = paidAmount;
            },
            DiscountedAmount: function () {

            },
            PaidAmount: function () {
                var paidAmount = parseFloat(formModel.PaidAmount || '0') || 0,
                    discountedAmount = parseFloat(formModel.DiscountedAmount || '0') || 0;
                formModel.DueAmount = discountedAmount - paidAmount;
                if (paidAmount > discountedAmount) {
                    alert("Paid Amount can not be gretter than Net Amount");
                    formModel.PaidAmount = discountedAmount;
                    formModel.DueAmount = 0;
                }
            },
            DueAmount: function () {
                var dueAmount = parseFloat(formModel.DueAmount || '0') || 0,
                    discountedAmount = parseFloat(formModel.DiscountedAmount || '0') || 0;
                formModel.PaidAmount = discountedAmount - dueAmount;
                if (dueAmount > discountedAmount) {
                    alert("Paid Amount can not be gretter than Net Amount");
                    formModel.PaidAmount = discountedAmount;
                    formModel.DueAmount = 0;
                }

            }
        };
        this.Bind = function () {
            ['DiscountP', 'DiscountT', 'DiscountedAmount', 'PaidAmount', 'DueAmount'].each(function () {
                $(inputs[this]).keyup(onChange[this]);
            });
        }
    }).call(service.Payment = {});
};