﻿
var Controller = new function () {
    var windowModel, formModel = {}, inputs = {}, callerOptions;
    
    function printReceipt(id) {
        Global.Add({
            type: 'New',
            BedAllocationId: id,
            name: 'ReceiptPrintPreview',
            url: '/Content/IqraHMS/BillingArea/Js/BedAllocation/PrintBedReceipt.js',
        });
    };

    function getModel() {
        var model = {
            PatientId: callerOptions.model.Id,
            PatientName: callerOptions.model.Name,
            DoctorId: formModel.DoctorId,
            RoomId: formModel.RoomId,
            BedId: formModel.BedId,
            BedNumber: formModel.BedNumber,
            Advance: formModel.Advance,
            Remarks: formModel.Remarks
        };
        return model;
    };
    //PatientName
    function save() {
        if (formModel.IsValid) {
            windowModel.Wait('Please Wait while saving data......');
            var model = getModel(),
                saveUrl = '/BillingArea/BedAllocation/Create';
            //model.Id = none;
            Global.CallServer(saveUrl, function (response) {
                windowModel.Free();
                if (!response.IsError) {
                    callerOptions.onSaveSuccess(formModel, inputs);
                    close();
                    printReceipt(response.Id);
                } else {
                    Global.Error.Show(response, {});
                }
            }, function (response) {
                windowModel.Free();
                //response.Id = -8;
                alert('Network Errors.');
            }, model, 'POST');
        } else {
            alert('Validation Error.');
        }
    }
    function close() {
        windowModel && windowModel.Hide();
    };
    function populate() {
        if (callerOptions.model) {
            var model = callerOptions.model;
            formModel.Name = model.Name;
            formModel.Mobile = model.Mobile;
            formModel.Email = model.Email;
            //Global.Copy(formModel, callerOptions.model, true);
        } else {
            for (var key in formModel) formModel[key] = '';
        }
        console.log(['callerOptions.model', callerOptions.model, formModel]);
        //Global.Copy(formModel, callerOptions.model, true);
        //formModel.Due = formModel.PaidAmount = callerOptions.model.TradePrice - callerOptions.model.PaidAmount;
        //printReceipt('6b3b879e-d696-4cf6-af32-41ee21354337');
    };
    function setDropdown() {
        var filterRoomModel = { field: 'RoomId', value: '00000000-0000-0000-0000-000000000000', Operation: 0 },
            dptFilter = { field: 'DepartmentId', Operation: 0 },
            dgnFilter = { field: 'DesignationId', Operation: 0, },
            doctor = {
                elm: $(inputs['DoctorId']),
                url: '/DoctorsArea/Doctor/AutoComplete',
                page: { 'PageNumber': 1, 'PageSize': 500, filter: [] },
                change: function (data) {
                    if (data) {
                        formModel.DoctorFees = data.Fee;
                        formModel.DoctorId = data.Id;
                    } else {
                        formModel.DoctorFees = 0;
                        formModel.DoctorId = '';
                    }
                }
            },
            department = {
                url: '/CommonArea/Department/AutoComplete',
                elm: $(inputs['DepartmentId']),
                change: function (data) {
                    if (data) {
                        dptFilter.value = data.Id;
                        //degination.page.filter = [dptFilter];
                        if (!dgnFilter.value) {
                            doctor.page.filter = [dptFilter];
                        }
                    } else {
                        dptFilter.value = none;
                        if (!dgnFilter.value) {
                            //degination.page.filter = [];
                            doctor.page.filter = [];
                        }
                    }
                    //degination.Reload();
                    doctor.Reload();
                }
            },
            degination = {
                elm: $(inputs['DesignationId']),
                url: '/CommonArea/Designation/DoctorAutoComplete',
                change: function (data) {
                    if (data) {
                        dgnFilter.value = data.Id;
                        doctor.page.filter = [dgnFilter];
                    } else if (dptFilter.value) {
                        doctor.page.filter = [dptFilter];
                        dgnFilter.value = none;
                    } else {
                        doctor.page.filter = [];
                    }
                    doctor.Reload();
                }
            },
            room = {
                elm: $(inputs['RoomId']),
                url: '/RoomArea/Room/AvailableRoomAutoCmpl',
                change: function (data) {
                    if (data) {
                        filterRoomModel.value = data.Id;
                        bed.Reload();
                    }
                }
            },
            bed = {
                elm: $(inputs['BedId']),
                url: '/RoomArea/Bed/AvailableBedAutoCmpl',
                page: { 'PageNumber': 1, 'PageSize': 500, filter: [filterRoomModel] },
                change: function (data) {
                    if (data) {
                        formModel.BedNumber = data.BedNumber;
                    } else {
                        formModel.BedNumber ='';
                    }
                }
            };

        Global.AutoComplete.Bind(department);
        Global.AutoComplete.Bind(degination);
        Global.AutoComplete.Bind(doctor);
        Global.AutoComplete.Bind(room);
        Global.AutoComplete.Bind(bed);
        console.log([doctor, department]);
    };
    this.Show = function (model) {
        callerOptions = model;
        if (windowModel) {
            windowModel.Show();
            populate();
        } else {
            Global.LoadTemplate('/Content/IqraHMS/PatientArea/Templates/AddRoomAllocationCreate.html', function (response) {
                windowModel = Global.Window.Bind(response);
                inputs = Global.Form.Bind(formModel, windowModel.View);
                windowModel.View.find('.btn_cancel').click(close);
                Global.Click(windowModel.View.find('.btn_save'), save);
                setDropdown();
                populate();
                windowModel.Show();
            }, noop);
        }
    };
};