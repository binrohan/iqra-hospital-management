﻿
var Controller = new function () {
    var windowModel, formModel = {}, inputs = {}, callerOptions, service = {}, invgridModel;
    var maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    function printInvoice(id) {
        Global.Add({
            type: 'New',
            PatientInvestigationId: id,
            name: 'InvoicePrintPreview',
            url: '/Content/IqraHMS/BillingArea/Js/InvestigationInvoice/PrintInvestigationInvoice.js',
        });
    };
    function getPatient() {
        var model = {
            Gender: formModel.Gender,
            Mobile: formModel.Mobile,
            DateOfBirth: formModel.DateOfBirth + ' 00:00',
            Name: formModel.Name
        };
        return model;
    };
    function getModel() {
        var model = {},
        invlist = service.Investigation.GetInvData();
        model.InvItems = invlist;
        model.DoctorId = formModel.DoctorId;
        model.ReferenceId = formModel.ReferenceId;
        model.DiscountRemarks = formModel.DiscountRemarks;
        model.DiscountType = formModel.DiscountType || 1;
        model.Type = formModel.Type;
        model.DrCommission = formModel.DrCommission;
        model.ReCommission = formModel.ReCommission;
        model.TotalAmount = formModel.TotalAmount;
        model.DiscountTaka = formModel.DiscountT;
        model.DiscountPercentage = formModel.DiscountP;
        model.DiscountedAmount = formModel.DiscountedAmount;
        model.PaidAmount = formModel.PaidAmount;
        model.DueAmount = formModel.DueAmount;
        model.Patient = getPatient();
        //model.PatientId = callerOptions.model.Id;
        console.log(['getModel', model]);
        return model;
    };
    function save() {
        if (formModel.IsValid) {
            windowModel.Wait('Please Wait while saving data......');
            var model = getModel();
            console.log(['save', model]);
            Global.CallServer('/InvestigationArea/PatientInvestigation/CreateInvestigationWithNonePatient', function (response) {
                windowModel.Free();
                if (!response.IsError) {
                    callerOptions.onSaveSuccess(formModel, inputs);
                    close();
                    printInvoice(response.Id);
                } else {
                    Global.Error.Show(response, {});
                }
            }, function (response) {
                windowModel.Free();
                alert('Network Errors.');
            }, model, 'POST');
            console.log(['after save', model]);
        } else {
            alert('Validation Error.');
        }
    };
    function close() {
        windowModel && windowModel.Hide();
    };
    function onDatePickerChanged(date) {
        if (date) {
            var currentDate = new Date();
            var value = currentDate.getDate() - date.getDate(), flg = 0;
            if (value < 0) {
                formModel.Day = (value + maxDays[date.getMonth()]);
                flg = -1; 
            } else {
                formModel.Day = value;
            }
            value = currentDate.getMonth() - date.getMonth() + flg; flg = 0;
            if (value < 0) {
                formModel.Month = (value + 12);
                flg = -1;
            } else {
                formModel.Month = value;
            }
            formModel.Year = currentDate.getFullYear() - date.getFullYear() + flg;
        } else {
            formModel.Year = 0;
            formModel.Month = 0;
            formModel.Day = 0;
        }
    };
    function onAgeChanged() {
        var date = new Date();
        date.setDate(date.getDate() - parseInt(formModel.Day || '0') || 0);
        date.setMonth(date.getMonth() - parseInt(formModel.Month || '0') || 0);
        date.setFullYear(date.getFullYear() - parseInt(formModel.Year || '0') || 0);
        formModel.DateOfBirth = date.format('dd/MM/yyyy');
    };
    function populate(isFirstTime) {
        if (callerOptions.model) {
            Global.Copy(formModel, callerOptions.model, true);
        } else {
            for (var key in formModel) formModel[key] = '';
        }
        service.DropDown.Reset(isFirstTime);
    };
    this.Show = function (model) {
        callerOptions = model;
        if (windowModel) {
            windowModel.Show();
            populate();
            service.Investigation.Empty();
        } else {
            Global.LoadTemplate('/Content/IqraHMS/InvestigationArea/Templates/CreateForNonePatient.html', function (response) {
                windowModel = Global.Window.Bind(response);
                inputs = Global.Form.Bind(formModel, windowModel.View);
                windowModel.View.find('.btn_cancel').click(close);
                Global.Click(windowModel.View.find('.btn_save'), save);
                service.Investigation.Bind();
                populate(true);
                windowModel.Show();
                service.Payment.Bind();
                service.DropDown.Bind();
                (['Day', 'Month', 'Year']).each(function () {
                    $(inputs[this + '']).keyup(onAgeChanged).blur(onAgeChanged);
                });
                Global.DatePicker.Bind($(inputs['DateOfBirth']), { format: 'dd/MM/yyyy', onchange: onDatePickerChanged });
            }, noop);
        }
    };
    (function () {//selectedValue: 'TransDate',
        var gendar = {
            dataSource: [
                { text: 'Male', value: 'Male' },
                { text: 'Female', value: 'Female' },
                { text: 'Other', value: 'Other' }
            ],
            selectedValue: 'Male'
        }, doctor = {
            url: '/DoctorsArea/Doctor/AutoComplete',
        }, discountType = {
            dataSource: [
                { text: 'Doctor', value: '1' },
                { text: 'Referral', value: '2' },
                { text: 'Hospital', value: '3' },
                { text: 'All', value: '4' }
            ],
            selectedValue: '1'
        }, reference = {
            url: '/ReferralArea/Reference/AutoComplete',
        };
        this.Bind = function () {
            doctor.elm = $(inputs['DoctorId']);
            discountType.elm = $(inputs['DiscountType']);
            reference.elm = $(inputs['ReferenceId']);
            gendar.elm = $(inputs['Gender']);


            Global.AutoComplete.Bind(doctor);
            Global.DropDown.Bind(discountType);
            Global.AutoComplete.Bind(reference);
            Global.DropDown.Bind(gendar);
        };
        this.Reset = function (isFirstTime) {
            formModel.DoctorId = '00000000-0000-0000-0000-000000000000';
            formModel.ReferenceId = '00000000-0000-0000-0000-000000000000';
            if (isFirstTime)
                return;

            doctor.val('');
            discountType.val('1');
            reference.val('');
            gendar.val('Male');
        };
    }).call(service.DropDown = {});
    (function () {
        var invsearchGridModel, filters = [],
            nameFilterModel = { "field": "Name", "value": "", Operation: 6 };
        function onDelete(model) {
            var list = [];
            //gridModel.datasource.each(function () {
            //    if (this.Id != model.Id) {
            //        list.push(this);
            //    }
            //});
            invgridModel.datasource = invgridModel.dataSource = invgridModel.dataSource.where('itm=>itm.Id != "' + model.Id + '"');
            invgridModel.Reload();
            calculateAmount();
        };
        //function rowBound(elm) {
        //    var td = elm.find('td');
        //    //$(td[1]).html(getInput('Name', false));
        //    var copy = Global.Copy({}, this);
        //    Global.Form.Bind(this, elm);
        //    Global.Copy(this, copy);
        //};
        function onSubmit(formModel, data) {
            var value = formModel.Cost;
            formModel.Cost = '';
            for (var i = 0; i < value.length; i++) {
                formModel.Cost += value[i];
            }
            console.log("formModel.Cost");
        };
        function calculateAmount() {
            var amount = 0;
            invgridModel.dataSource.each(function () {
                amount += this.Cost;
            });

            formModel.TotalAmount = amount;
            service.Payment.OnChange.DiscountP();
        };
        function calculateDiscountedAmount() {

        }
        function setInvGridModel() {
            Global.List.Bind({
                Name: 'Investigation',
                Grid: {
                    elm: windowModel.View.find('#investigation_grid_container'),
                    columns: [
                        { field: 'CategoryName', title: 'Category Name', filter: true },
                        { field: 'Name', title: 'Investigation Name', filter: true },
                        { field: 'Cost', title: 'Amount' },

                    ],
                    Actions: [{
                        click: onDelete,
                        html: '<a style="margin-right:8px;" class="icon_container" title="Delete"><span class="glyphicon glyphicon-trash"></span></a>'
                    }],
                    dataSource: [],
                    Printable: false,
                    Responsive: false,
                    selector: false,
                    page: { 'PageNumber': 1, 'PageSize': 1000, showingInfo: ' {0}-{1} of {2} Investigations ' },
                    //onDataBinding: onDataBinding,
                    //rowBound: rowBound
                },
                onComplete: function (model) {
                    console.log(model);
                    invgridModel = model;
                },
                Add: false,
                Edit: false,
                remove: false
            });
        };
        function getInvModel(model) {
            var inv = {
                Name: model.Name,
                Cost: model.Cost,
                Id: model.Id,
                Type: model.Type,
                CategoryName: model.InvestigationCategory,
                InvestigationCategoryId: model.InvestigationCategoryId
            };
            inv.DrCommission = model.DrCommission < 0 ? model.CtgrDrCommission : model.DrCommission;
            inv.ReCommission = model.ReCommission < 0 ? model.CtgrReCommission : model.ReCommission;
            return inv;
        };
        function setInvSearchGridModel() {
            filters = [nameFilterModel];
            Global.Grid.Bind({
                elm: windowModel.View.find('#inv_search_grid_container'),
                columns: [
                    { field: 'Name', title: 'Investigation Name', filter: true },
                    { field: 'Cost', title: 'Cost', filter: true },
                    { field: 'MaxDiscount', title: 'Max Discount', filter: true },
                ],
                Printable: false,
                Responsive: false,
                selector: false,
                //dataSource: [],
                url: '/InvestigationArea/Investigation/Get',
                page: { 'PageNumber': 1, 'PageSize': 10, showingInfo: ' {0}-{1} of {2} Investigations ', filter: filters },
                rowBound: function (elm) {
                    Global.Click(elm, function (model) {
                        if (invgridModel.dataSource.where('itm=>itm.Id=="' + model.Id + '"').length < 1) {
                            invgridModel.dataSource.push(getInvModel(model));
                            invgridModel.Reload();
                            calculateAmount();
                            windowModel.View.find('#inv_search_grid_container').hide();
                            $(inputs['InvestigationId']).blur();
                        } else {
                            alert('This Item is already Added.');
                        }
                    }, this);
                },
                onSubmit: onSubmit,
                onComplete: function (model) {
                    model.dataSource = none;
                    invsearchGridModel = model;
                    windowModel.View.find('#inv_search_grid_container').hide();
                }
            });
        };
        function setCommission(model, position) {
            var inv = {
                InvestigationId: model.Id,
                Cost: model.Cost,
                CommissionType: model.Type,
                Position: position
            };
            var dt = parseFloat(formModel.DiscountT || '0') || 0;
            var dp = parseFloat(formModel.DiscountP || '0') || 0;
            if (dt > 0) {
                if (formModel.DiscountType === '4') {
                    var cost = model.Cost - dt;
                    if (model.Type == 'Percentage') {
                        inv.DrCommission = cost.mlt(model.DrCommission).div(100);
                        inv.ReCommission = cost.mlt(model.ReCommission).div(100);
                    } else {
                        inv.DrCommission = model.DrCommission - model.DrCommission.mlt(dp).div(100);
                        inv.ReCommission = model.ReCommission - model.ReCommission.mlt(dp).div(100);
                    }
                } else if (formModel.DiscountType === '3') {
                    if (model.Type == 'Percentage') {
                        inv.DrCommission = model.Cost.mlt(model.DrCommission).div(100);
                        inv.ReCommission = model.Cost.mlt(model.ReCommission).div(100);
                    } else {
                        inv.DrCommission = model.DrCommission;
                        inv.ReCommission = model.ReCommission;
                    }
                } else if (formModel.DiscountType === '2') {
                    if (model.Type == 'Percentage') {
                        inv.DrCommission = model.Cost.mlt(model.DrCommission).div(100);
                        inv.ReCommission = model.Cost.mlt(model.ReCommission - dp).div(100);
                    } else {
                        inv.DrCommission = model.DrCommission;
                        inv.ReCommission = model.ReCommission - model.Cost.mlt(dp).div(100);
                    }
                } else if (formModel.DiscountType === '1') {
                    if (model.Type == 'Percentage') {
                        inv.DrCommission = model.Cost.mlt(model.DrCommission - dp).div(100);
                        inv.ReCommission = model.Cost.mlt(model.ReCommission).div(100);
                    } else {
                        inv.DrCommission = model.DrCommission - model.Cost.mlt(dp).div(100);
                        inv.ReCommission = model.ReCommission;
                    }
                }
            } else {
                if (model.Type == 'Percentage') {
                    inv.DrCommission = model.Cost.mlt(model.DrCommission).div(100);
                    inv.ReCommission = model.Cost.mlt(model.ReCommission).div(100);
                } else {
                    inv.DrCommission = model.DrCommission;
                    inv.ReCommission = model.ReCommission;
                }
            }
            return inv;
            //public DateTime DeliveryDate { get; set; }= DateTime.MaxValue

        };
        this.Bind = function () {
            setInvGridModel();
            setInvSearchGridModel();
            $(inputs['InvestigationId']).focus(function () {
                var offset = $(this).offset();
                offset.top += 15 - $(document).scrollTop();
                offset.left = 0;
                windowModel.View.find('#inv_search_grid_container').css(offset).show();
            }).keyup(function () {
                if (formModel.InvestigationId != nameFilterModel.value) {
                    nameFilterModel.value = formModel.InvestigationId;
                    //invsearchGridModel.dataSource = invsearchGridModel.datasource = none;
                    invsearchGridModel.Reload();
                }
            }).blur(function () {
                //windowModel.View.find('#inv_search_grid_container').hide();
            }).closest('.input-group').mousedown(function (e) {
                e.stopPropagation();
            });
            windowModel.View.find('#inv_search_grid_container').mousedown(function (e) {
                e.stopPropagation();
            });
            $(document).mousedown(function () {
                windowModel.View.find('#inv_search_grid_container').hide();
            });
        };
        this.Get = function () {
            return invgridModel.dataSource;
        };
        this.GetInvData = function () {
            var invlist = [];
            invgridModel.dataSource.each(function (i) {
                invlist.push(setCommission(this, i))
            });
            return invlist;
        };
        this.Empty = function () {
            invgridModel.dataSource = invgridModel.datasource = [];
            invgridModel.Reload();
        };
    }).call(service.Investigation = {});
    (function () {
        var onChange = this.OnChange = {
            DiscountP: function () {
                var total = parseFloat(formModel.TotalAmount || '0') || 0,
                    discountP = parseFloat(formModel.DiscountP || '0') || 0,
                    dueAmount = parseFloat(formModel.DueAmount || '0') || 0,
                    paidAmount = parseFloat(formModel.PaidAmount || '0') || 0,
                    discount = Math.ceil(total.mlt(discountP).div(100));

                formModel.DiscountT = discount;
                formModel.DiscountedAmount = total - discount;
                var discountedAmount = parseFloat(formModel.DiscountedAmount || '0') || 0;
                //var paidAmount = Math.min(paidAmount, discountedAmount);
                var paidAmount = formModel.DiscountedAmount;
                formModel.DueAmount = discountedAmount - paidAmount;
                formModel.PaidAmount = paidAmount;
                if (discountP > 100) {
                    alert("Discounted percent can not be gretter than 100%");
                    formModel.DiscountP = 100;
                    formModel.DiscountT = total;
                    formModel.DiscountedAmount = 0;
                    formModel.DueAmount = 0;
                    formModel.PaidAmount = 0;
                }
            },
            DiscountT: function () {
                var total = parseFloat(formModel.TotalAmount || '0') || 0,
                    discountT = Math.ceil(parseFloat(formModel.DiscountT || '0') || 0),
                    dueAmount = parseFloat(formModel.DueAmount || '0') || 0,
                    paidAmount = parseFloat(formModel.PaidAmount || '0') || 0,
                    discount = Math.ceil(discountT.mlt(100).div(total));


                formModel.DiscountP = discount;
                formModel.DiscountedAmount = total - discountT;
                var discountedAmount = parseFloat(formModel.DiscountedAmount || '0') || 0;
                var paidAmount = Math.min(paidAmount, discountedAmount);
                formModel.DueAmount = discountedAmount - paidAmount;
                formModel.PaidAmount = paidAmount;
                if (discountT > total) {
                    alert("Discounted Taka can not be gretter than TotalAmount");
                    var discountT = total;
                    var discountP = Math.ceil(discountT.mlt(100).div(total));
                    formModel.DiscountT = discountT;
                    formModel.DiscountP = discountP;
                    formModel.DiscountedAmount = 0;
                    formModel.DueAmount = 0;
                    formModel.PaidAmount = 0;
                };

            },
            DiscountedAmount: function () {

            },
            PaidAmount: function () {
                var paidAmount = parseFloat(formModel.PaidAmount || '0') || 0,
                    discountedAmount = parseFloat(formModel.DiscountedAmount || '0') || 0;
                formModel.DueAmount = discountedAmount - paidAmount;
                if (paidAmount > discountedAmount) {
                    alert("Paid Amount can not be gretter than Net Amount");
                    formModel.PaidAmount = discountedAmount;
                    formModel.DueAmount = 0;
                }
            },
            DueAmount: function () {
                var dueAmount = parseFloat(formModel.DueAmount || '0') || 0,
                    discountedAmount = parseFloat(formModel.DiscountedAmount || '0') || 0;
                formModel.PaidAmount = discountedAmount - dueAmount;
                if (dueAmount > discountedAmount) {
                    alert("Paid Amount can not be gretter than Net Amount");
                    formModel.PaidAmount = discountedAmount;
                    formModel.DueAmount = 0;
                }

            }
        };
        this.Bind = function () {
            ['DiscountP', 'DiscountT', 'DiscountedAmount', 'PaidAmount', 'DueAmount'].each(function () {
                $(inputs[this]).keyup(onChange[this]);
            });
        }
    }).call(service.Payment = {});
};