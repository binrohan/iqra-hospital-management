
(function () {
    var that = this, gridModel;
    function onSubmit(formModel, data) {
        if (data) {
            formModel.Id = data.Id
        }
    };
    function onCreatorDetails(model) {
        Global.Add({
            UserId: model.CreatedBy,
            name: 'UserDetails',
            url: '/Content/IqraHMS/PatientArea/Js/User/UserDetails.js',
        });
    }
    function onDetails(model) {
        Global.Add({
            model: model,
            name: 'InvestigationDetails',
            url: '/Content/IqraHMS/InvestigationArea/Js/Investigation/OnDetails.js',
        });
    }
    function rowBound(elm) {
        if (this.IsDeleted) {
            elm.css({ color: 'red' }).find('.glyphicon-trash').css({ opacity: 0.3, cursor: 'default' });
            elm.find('a').css({ color: 'red' });
        }
    };
    function onDataBinding(data) {

    };
    Global.List.Bind({
        Name: 'Investigation',
        Grid: {
            elm: $('#grid'),
            columns: [
                    { field: 'Name', title: 'Test Name', filter: true, position: 4, Add: { sibling: 3 }, click: onDetails },
                    { field: 'InvestigationCategory', title: 'Category', filter: true, Add: false, position: 1 },
                    { field: 'Room', title: 'Room', filter: true, Add: false, position: 3 },
                    { field: 'Cost', title: 'Cost', position: 9, Type: 2, Add: { sibling: 3, dataType: 'float' } },
                    { field: 'MaxDiscount', title: 'Max Discount', position: 9, Type: 2, required: false, selected: false, Add: { sibling: 3, dataType: 'float|null' } },
                    { field: 'Type', title: 'Commission Type', filter: true, Add: false },
                    { field: 'DrCommission', title: 'Doctor Commission', filter: true, },
                    { field: 'ReCommission', title: 'Reference Commission', filter: true, },

                    { field: 'CreatedAt', title: 'CreatedAt', dateFormat: 'dd mmm-yyyy', Add: false, selected: false },
                    { field: 'UpdatedAt', title: 'UpdatedAt', dateFormat: 'dd mmm-yyyy', Add: false, selected: false },
                    { field: 'Creator', add: false, filter: true, click: onCreatorDetails },
                    { field: 'Remarks', title: 'Remarks', filter: true, required: false, Add: { type: 'textarea', sibling: 1 } }

	  //,rm.[Name] [Room]
      //,inv.[Cost]
      //,inv.[MaxDiscount]
                    
            ],
            url: '/InvestigationArea/Investigation/Get',
            page: { 'PageNumber': 1, 'PageSize': 10, showingInfo: ' {0}-{1} of {2} Investigations ' },
            onDataBinding: onDataBinding,
            rowBound: rowBound
        },
        onComplete: function (model) {
            gridModel = model;
        },
        Add: {
            onSubmit: onSubmit,
            save: '/InvestigationArea/Investigation/Create',
            saveChange: '/InvestigationArea/Investigation/Edit',
            dropdownList: [
                {
                    Id: 'InvestigationCategoryId',
                    position: 1,
                    url: '/InvestigationArea/InvestigationCategory/AutoComplete',
                    onChange: function (data) {
                        console.log(data);
                    },
                    Type: 'AutoComplete',
                },
                {
                    Id: 'RoomId',
                    position: 3,
                    url: '/RoomArea/Room/AutoComplete',
                    onChange: function (data) {
                        console.log(data);
                    },
                    Type: 'AutoComplete',
                },
                {
                     Id: 'Type', position: 5,
                     dataSource: [
                         { text: 'Percentage(%)', value: 'Percentage' },
                         { text: 'Fixed of commission', value: 'Fixed' },
                         
                     ]
                 }
            ]
        },
        remove: { save: '/InvestigationArea/Investigation/Delete' }
    });

})();;
                