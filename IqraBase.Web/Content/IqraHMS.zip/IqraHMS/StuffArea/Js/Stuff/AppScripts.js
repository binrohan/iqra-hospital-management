(function () {
    function onSubmit(formModel, data) {
        if (data) {
            formModel.Id = data.Id
        }
    };
    function onDetails(model) {
        Global.Add({
            StuffId: model.Id,
            name: 'StuffDetails',
            url: '/Content/IqraHMS/StuffArea/Js/Stuff/StuffDetails.js',
        });
    };
    function onAddOrderCategory(model) {
        Global.Add({
            model: model,
            name: 'OrderCategory',
            url: '/Areas/SuplierArea/Content/Suplier/AddOrderCategoryController.js',
        });
    };
    function onUserDetails(userId) {
        Global.Add({
            UserId: userId,
            name: 'UserDetails',
            url: '/Areas/EmployeeArea/Content/User/UserDetails.js',
        });
    };
    function onCreatorDetails(model) {
        onUserDetails(model.CreatedBy);
    }
    function onUpdatorDetails(model) {
        onUserDetails(model.UpdatedBy);
    }
    function rowBound(elm) {
        if (this.IsDeleted) {
            elm.css({ color: 'red' }).find('.glyphicon-trash').css({ opacity: 0.3, cursor: 'default' });
            elm.find('a').css({ color: 'red' });
        }
    };
    function onDataBinding(data) {

    };
    var that = this, gridModel;
    Global.List.Bind({
        Name: 'Stuff',
        Grid: {
            elm: $('#grid'),
            columns: [

                    { field: 'Name', title: 'Name', filter: true, position: 1, Click: onDetails },
                    { field: 'EmployeeCode', title: 'Stuff Code', filter: true, position: 2, Add: false },
                    { field: 'Gender', title: 'Gender', filter: true, Add: false, position: 3 },
                    { field: 'EmployeeType', title: 'Stuff Type', filter: true, Add: false, position: 4 },
                    { field: 'Designation', title: 'Designation', filter: true, width: 110, Add: false, position: 5 },
                    { field: 'Mobile', title: 'Mobile', filter: true, width: 110 },
                    { field: 'Email', title: 'Email', filter: true },
                    { field: 'Address', title: 'Address', Add: { type: 'textarea' } },
                    { field: 'CreatedAt', title: 'Created At', dateFormat: 'dd mmm-yyyy', Add: false },
                    { field: 'UpdatedAt', title: 'Updated At', dateFormat: 'dd mmm-yyyy', Add: false },
                    //{ field: 'PassWord', title: 'PassWord', position: 6, filter: true, add: { type: 'password' } },
                    { field: 'Remarks', title: 'Remarks', Add: { type: 'textarea' }, required: false }
                    
            ],
            //Actions: [{
            //    click: onAddOrderCategory,
            //    html: '<a style="margin-right:8px;" class="icon_container" title="Add Order Category"><span class="glyphicon glyphicon-open"></span></a>'
            //}],
            url: '/StuffArea/Stuff/Get',
            page: { 'PageNumber': 1, 'PageSize': 10, showingInfo: ' {0}-{1} of {2} Stuffs ' },
            onDataBinding: onDataBinding,
            rowBound: rowBound
        }, onComplete: function (model) {
            gridModel = model;
        }, Add: {
            onSubmit: onSubmit,
            save: '/StuffArea/Stuff/Create',
            saveChange: '/StuffArea/Stuff/Edit',
            dropdownList: [
                            {
                                Id: 'Gender', position: 3, Add: { sibling: 3 },
                                dataSource: [
                                    { text: 'Male', value: 'Male' },
                                    { text: 'Female', value: 'Female' },
                                    { text: 'Other', value: 'Other' }
                                ]
                            },
                            {
                                Id: 'EmployeeTypeId',
                                position: 4,
                                url: '/CommonArea/EmployeeType/AutoComplete',
                                onChange: function (data) {
                                    console.log(data);
                                },
                                Type: 'AutoComplete',
                                change: {
                                    Id: 'DesignationId',
                                    position: 5,
                                    ValuField: 'Id',
                                    TextField: 'Name',
                                    url: function (data) {
                                        console.log(['/CommonArea/Designation/AutoComplete', data]);
                                        if (data) {
                                            return '/CommonArea/Designation/DesignationByAutoComplete?PageSize=2000&TypeId=' + data.Id;
                                        }
                                        return false;
                                    },
                                    Type: 'AutoComplete'
                                },
                }

            ],
           
        },
        remove: { save: '/StuffArea/Stuff/Delete' },
        additionalField: [
                   { field: 'PassWord', title: 'PassWord', position: 6, filter: true, Add: { type: 'password' } },
        ]
    });

})();;
                