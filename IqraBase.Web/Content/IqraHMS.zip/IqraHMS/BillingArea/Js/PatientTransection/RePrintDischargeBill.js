﻿
var Controller = new function () {
    var windowModel, formModel = {}, inputs = {}, callerOptions, summaryModel, service = {};
    function getTime(str) {
        return Global.DateTime.GetObject(str, 'dd/MM/yyyy hh:mm').getTime();
    };
    function getItemModel() {
        var list = [], item;
        summaryModel.List.each(function () {
            item = {
                PatientId: callerOptions.PatientId,
                Unit: this.Unit,
                Rate: this.Rate,
                Total: this.Total,
                ServiceType: this.ServiceType,
                ServiceId: this.RelatedId,
                TransectionType: this.TransectionType,
                RelatedId: this.RelatedId
            };
            list.push(item);
        });
        return list;
    };
    function getModel() {
        var model = {
            PatientId: callerOptions.PatientId,
            Items: getItemModel(),
            Total: summaryModel.Total,
            Vat: 0,
            Discount: summaryModel.Discount,
            Paid: summaryModel.Paid,
            NetPayable: summaryModel.NetPayable,
            ChangeAmount: summaryModel.Total - formModel.ChangeAmount,
            Discount: summaryModel.Discount,
        };
        return model;
    };
    function save() {
        if (formModel.IsValid) {
            windowModel.Wait('Please Wait while saving data......');
            var model = getModel(),
                saveUrl = '/TransectionArea/PatientTransection/SetDischargeBill';
            Global.CallServer(saveUrl, function (response) {
                windowModel.Free();
                if (!response.IsError) {
                    service.PrintService.Print();
                    callerOptions.onSaveSuccess(formModel, inputs);
                    close();
                } else {
                    Global.Error.Show(response, {});
                }
            }, function (response) {
                windowModel.Free();
                alert('Network Errors.');
            }, model, 'POST');
        } else {
            alert('Validation Error.');
        }
    }
    function close() {
        windowModel && windowModel.Hide();
    };
    function setSummary(model) {
        for (var key in model) {
            if (key != 'List')
                formModel[key] = ' &#2547; ' + model[key].toMoney() + '/-';
        }
        formModel.NetAmount = ' &#2547; ' + (model.Total - model.Discount).toMoney() + '/-';
    };
    function getTd(name, stl) {
        return '<td class ="item-name" ' + stl + '><div>' + name + ' </div></td>'
    };
    function createItem(container, item) {
        var tr = $('<tr class="item-row">' +
                        getTd(item.TransectionType, 'style="padding:2px 10px;"') +
                         getTd(item.Unit, 'style="padding:2px 10px; text-align:center;"') +
                         getTd(item.Rate.toMoney(), 'style="padding:2px 10px; text-align:right;"') +
                        getTd(' &#2547; ' + item.Total.toMoney() + '/-', 'style="padding:2px 10px; text-align:right;"') +
                    '</tr>');
        container.append(tr);
    };
    function populate(model) {
        var patientModel = model[0][0],
            itemContainer = windowModel.View.find('#items tbody').empty();

        for (var key in formModel) {
            if (typeof patientModel[key] != 'undefined') {
                formModel[key] = patientModel[key];
            }
        }
        formModel.BedNumber = patientModel.BedNumber + '(' + patientModel.BedType + ')';

        setSummary(model[1][0]);

        summaryModel = {List:model[3]  };
        model[3].each(function () {
            createItem(itemContainer, this);
        });
        currentDate = model[2][0].CurrentDate.getDate();
        patientModel.DateOfBirth = patientModel.DateOfBirth.getDate();
        patientModel.PatientAge = new Date(currentDate.getTime() - patientModel.DateOfBirth.getTime());
        patientModel.PatientAge.setFullYear(patientModel.PatientAge.getFullYear() - 1970);
        formModel.PatientAge = patientModel.PatientAge.getFullYear() + ' yrs ' + (patientModel.PatientAge.getMonth() + 1) + ' mnths ' + patientModel.PatientAge.getDate() + ' days ';
        formModel.PrintedAt = currentDate.format('dd/MM/yyyy hh:mm');
    };
    function load() {
        windowModel.Wait('Please wait while loading data');
        Global.CallServer('/TransectionArea/PatientTransection/GetRePrintBill?Id=' + callerOptions.PatientId, function (response) {
            windowModel.Free();
            if (!response.IsError) {
                populate(response.Data);
            } else {
                Global.Error.Show(response, {});
            }
        }, function (response) {
            windowModel.Free();
            response.Id = -8;
            Global.Error.Show(response, {});
        }, null, 'Get');
    };
    this.Show = function (model) {
        callerOptions = model;
        if (windowModel) {
            windowModel.Show();
            load();
        } else {
            Global.LoadTemplate('/Content/IqraHMS/BillingArea/Templates/PrintPatientTransection.html', function (response) {
                windowModel = Global.Window.Bind(response);
                inputs = Global.Form.Bind(formModel, windowModel.View);
                windowModel.View.find('.btn_cancel').click(close);
                Global.Click(windowModel.View.find('.btn_save'), service.PrintService.Print);
                //load();
                load();
                windowModel.Show();
                if (callerOptions.Type === 'DischargePrint') {
                    formModel.PaymentStatus = 'Paid';
                    windowModel.View.find('#amount_paid').remove();
                    windowModel.View.find('#net_payable').remove();
                }
            }, noop);
        }
    };

    (function () {
        function printElem(view) {
            var mywindow = window.open('', 'PRINT', 'height=800,width=1200');
            mywindow.document.write('<html><head><title>' + 'Appointment Charge' + '</title>');
            mywindow.document.write('<link href="/Content/bootstrap.min.css" rel="stylesheet" /><script src="/Content/IqraService/Js/global.js"></script><style type="text/css" media="print">@page{size:  auto;margin: 0mm;}html{background-color: #FFFFFF;margin: 0px;}</style></head>');
            mywindow.document.write('<body style="padding: 20px;">');

            mywindow.document.write(view)
            mywindow.document.write('<script type="text/javascript"> $(document).ready(function () { window.print();});</script>');
            mywindow.document.write('</body></html>');
            mywindow.document.close(); // necessary for IE >= 10
            mywindow.focus();
            return true;
        };
        function getTd(name, stl) {
            return '<td class ="item-name" ' + stl + '><div>' + name + ' </div></td>'
        };
        function createItem(container, item) {
            var tr = $('<tr class="item-row">' +
                            getTd(item.TransectionType, 'style="padding:2px 10px;"') +
                             getTd(item.Unit, 'style="padding:2px 10px; text-align:center;"') +
                             getTd(item.Rate.toMoney(), 'style="padding:2px 10px; text-align:right;"') +
                            getTd(' &#2547; ' + item.Total.toMoney() + '/-', 'style="padding:2px 10px; text-align:right;"') +
                        '</tr>');
            container.append(tr);
        };
        function print() {
            var view = $(windowModel.View.find('#print_container').html()),
            itemContainer = view.find('#items tbody').empty();
            summaryModel.List.each(function () {
                createItem(itemContainer, this);
            });
            printElem(view.html());
        };
        this.Print = function () {
            print();
        };
    }).call(service.PrintService = {});
};