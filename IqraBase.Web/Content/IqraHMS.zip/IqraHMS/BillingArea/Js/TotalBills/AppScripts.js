
(function () {
    function onSubmit(formModel, data) {
        if (data) {
            formModel.Id = data.Id
        }
    };
    function onDetails(model) {
        Global.Add({
            TotalBillsId: model.Id,
            name: 'TotalBillsDetails',
            url: '/Areas/BillingArea/Content/TotalBills/TotalBillsDetails.js',
        });
    };
    function onAddOrderCategory(model) {
        Global.Add({
            model: model,
            name: 'OrderCategory',
            url: '/Areas/SuplierArea/Content/Suplier/AddOrderCategoryController.js',
        });
    };
    function onUserDetails(userId) {
        Global.Add({
            UserId: userId,
            name: 'UserDetails',
            url: '/Areas/EmployeeArea/Content/User/UserDetails.js',
        });
    };
    function onCreatorDetails(model) {
        onUserDetails(model.CreatedBy);
    }
    function onUpdatorDetails(model) {
        onUserDetails(model.UpdatedBy);
    }
    function rowBound(elm) {
        if (this.IsDeleted) {
            elm.css({ color: 'red' }).find('.glyphicon-trash').css({ opacity: 0.3, cursor: 'default' });
            elm.find('a').css({ color: 'red' });
        }
    };
    function onDataBinding(data) {

    };
    var that = this, gridModel;
    Global.List.Bind({
        Name: 'TotalBills',
        Grid: {
            elm: $('#grid'),
            columns: [
                
                    { field: 'DoctorFees', title: 'D.Fees' ,width: 60},
                    { field: 'TestFees', title: 'T.Fees', width: 60 },
                    { field: 'AdmissionCharge', title: 'Ad.Charge', width: 70 },
                    { field: 'RoomCharge', title: 'RoomCharge', width: 85 },
                    { field: 'BedCharge', title: 'BedCharge', width: 80 },
                    { field: 'TotalAmount', title: 'TotalAmount', width: 90 },
                    { field: 'Discount', title: 'Discount', width: 60 },
                    { field: 'DiscountedAmount', title: 'Diss.Amount', width: 80 },
                    { field: 'PaidAmount', title: 'PaidAmount', width: 80 },
                    { field: 'DueAmount', title: 'DueAmount', width: 75 },
                    //{ field: 'Remarks', title: 'Remarks', filter: true, width: 60 },
                    { field: 'IsPaid', title: 'IsPaid', Add: false, width: 50 },
                    { field: 'IsDeleted', title: 'Deleted', Add: false, width: 50 },
                    { field: 'CreatedAt', title: 'CreatedAt', dateFormat: 'dd mmm-yyyy', Add: false, width: 70 },
                    { field: 'UpdatedAt', title: 'UpdatedAt', dateFormat: 'dd mmm-yyyy', Add: false, width: 70 },
                    
            ],
            //Actions: [{
            //    click: onAddOrderCategory,
            //    html: '<a style="margin-right:8px;" class="icon_container" title="Add Order Category"><span class="glyphicon glyphicon-open"></span></a>'
            //}],
            url: '/BillingArea/TotalBills/Get',
            page: { 'PageNumber': 1, 'PageSize': 10, showingInfo: ' {0}-{1} of {2} TotalBillss ' },
            onDataBinding: onDataBinding,
            rowBound: rowBound,
            Action:{width:60}
        }, onComplete: function (model) {
            gridModel = model;
        }, Add: {
            onSubmit: onSubmit,
            save: '/BillingArea/TotalBills/Create',
            saveChange: '/BillingArea/TotalBills/Edit',
            //details: function (data) {
                //return '/BillingArea/TotalBills/Details?Id=' + data.Id;
            //},
            additionalField: [
                //{ field: 'AccountNo', required: false, title: 'Payable Account No', position: 2 },
                //{ field: 'AccountName', required: false, title: 'Payable Account Name', position: 2 },
                //{ field: 'Fax', required: false, position: 5 },
                //{ field: 'Vat', position: 8 },
                //{ field: 'Discount', position: 9 },
                //{ field: 'PurchaseDiscount', position: 10 },
                //{ field: 'Remarks', required: false, position: 12, Add: { type: 'textarea' } }
            ]
        },
        remove: { save: '/BillingArea/TotalBills/Delete' }
    });

})();;
                